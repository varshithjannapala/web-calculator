# Simple Calculator

This is a basic web-based calculator built using HTML, CSS, and JavaScript.

## Features
- Perform addition, subtraction, multiplication, and division.
- User-friendly interface.
- Live output display.

## How to Use
1. Download or clone the repository.
2. Open `index.html` in your web browser.
3. Use the calculator interface to perform operations.

## Live Demo
(Enable GitHub Pages after uploading to access the live version.)
